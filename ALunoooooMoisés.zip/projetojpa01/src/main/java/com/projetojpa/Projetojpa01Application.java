package com.projetojpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projetojpa01Application {

	public static void main(String[] args) {
		SpringApplication.run(Projetojpa01Application.class, args);
	}

}
