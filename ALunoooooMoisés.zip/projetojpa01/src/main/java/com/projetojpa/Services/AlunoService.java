package com.projetojpa.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.projetojpa.entities.Produto;
import com.projetojpa.repositories.AlunoRepository;


@Service
public class AlunoService {
	
private final AlunoRepository Alunorepository;
	
@Autowired
public AlunoService(AlunoRepository Alunorepository) {
	this.Alunorepository = Alunorepository;
}

public Produto saveAluno(Produto aluno) {
	return Alunorepository.save(aluno);
}

public Produto getAlunoById(long idAluno) {
	return Alunorepository.findById(idAluno).orElse(null);
}

public List<Produto> getAllAluno(){
	return Alunorepository.findAll();
}

public void deleteAluno(Long idAluno) {
	Alunorepository.deleteById(idAluno);
}


}

