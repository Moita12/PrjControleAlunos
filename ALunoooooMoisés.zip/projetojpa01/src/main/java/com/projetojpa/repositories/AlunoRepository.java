package com.projetojpa.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.projetojpa.entities.Produto;

public interface AlunoRepository extends JpaRepository<Produto, Long>{}
